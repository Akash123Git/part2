import React from 'react'

export default class Contact extends React.Component
{
    render()
    {
        return <div>
            <h2>Contact Component</h2>
            <img src="https://raw.githubusercontent.com/Gourav4hub/alchemycode/main/23dec/web23dec/public/imgs/img2.jpg"/>
        </div>
    }
}