import React from 'react'

export default class Home extends React.Component
{

    constructor(){
        super()
        this.state={
            img:"https://raw.githubusercontent.com/Gourav4hub/alchemycode/main/23dec/web23dec/public/imgs/img3.jpg",
        }
    }

    render()
    {
        

        
        return <div>
            <h2>Home Component</h2>
            <img src={this.state.img} alt='hello' / >
        </div>
    }
}