import React from 'react'
import About from './About/About';
import Menu from './menu/Menu';
import MyWork from './work/Work';
import Contact from './contact/Contact'
import {Routes,Route} from 'react-router-dom'
class App extends React.Component
{  
    render()
    {     
      return <div id="page-wraper">  

      <Menu/>

      <Routes>
        <Route path="/" element={<About/>}/>
        <Route path="/work" element={<MyWork/>}/>
        <Route path="/contact" element={<Contact/>}/>
      </Routes>

    </div>

    }
}

export default App;