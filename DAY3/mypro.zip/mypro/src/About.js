import React from 'react'

export default class About extends React.Component
{
    render()
    {
        return <div>
            <h2>About Component</h2>
            <img src="https://raw.githubusercontent.com/Gourav4hub/alchemycode/main/23dec/web23dec/public/imgs/img1.jpg"/>
        </div>
    }
}